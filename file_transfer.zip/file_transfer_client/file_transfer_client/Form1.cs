﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Windows.Forms.VisualStyles;
using System.Threading;

namespace file_transfer_client
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		TcpClient client = null;
		IPAddress ipAddress = null;
		int port = 0;
		string file_directory = "";

		private void bt_connect_Click(object sender, EventArgs e)
		{
			try
			{
				ipAddress = IPAddress.Parse(tb_ip.Text);
			}
			catch
			{
				MessageBox.Show("Invalid IP address format.");
				return;
			}

			try
			{
				port = int.Parse(tb_port.Text);
			}
			catch
			{
				MessageBox.Show("Invalid port number.");
				return;
			}

			if (port < 1 || port > 65535)
			{
				MessageBox.Show("Port number must be between 1 and 65535.");
				return;
			}

			if (client != null)
			{
				MessageBox.Show("Already connected.");
				return;
			}

			if (file_directory == "")
			{
                MessageBox.Show("No directory selected.");
                return;
            }

			if (lb_files.Items.Count > 0)
			{
				lb_files.Items.Clear();
			}

			if (lb_log.Items.Count > 0)
			{
                lb_log.Items.Clear();
            }

			client = new TcpClient();
			client.Connect(ipAddress, port);

			recieve_file_structure();

			bt_disconnect.Enabled = true;
			bt_download.Enabled = true;
			bt_connect.Enabled = false;
			tb_ip.Enabled = false;
			tb_port.Enabled = false;
			bt_changeDir.Enabled = false;
		}

		private void bt_disconnect_Click(object sender, EventArgs e)
		{
			if (client != null)
			{
				client.Close();
				client = null;

				lb_files.Items.Clear();
				lb_log.Items.Clear();

				bt_connect.Enabled = true;
				tb_ip.Enabled = true;
				bt_changeDir.Enabled = true;
				bt_disconnect.Enabled = false;
				tb_port.Enabled = true;
				bt_download.Enabled = false;
			}
		}

		private void recieve_file_structure()
		{
			NetworkStream stream = client.GetStream();
			byte[] buffer = new byte[1024];
			stream.Read(buffer, 0, buffer.Length);

			string[] files = Encoding.ASCII.GetString(buffer).Split(':');

			foreach (string file in files)
			{
				if (!string.IsNullOrEmpty(file))
				{
					lb_files.Items.Add(file);
				}
			}
		}

		private byte[] recieve_again(int sequence_number, string file_name, IPEndPoint remoteEP)
		{
			UdpClient udp_client = new UdpClient(9000);
			NetworkStream stream = client.GetStream();
			byte[] buffer = Encoding.ASCII.GetBytes("GETP:" + file_name + ":" + sequence_number + ":");
			stream.Write(buffer, 0, buffer.Length);


			while (true)
			{
				try
				{
					byte[] packet = udp_client.Receive(ref remoteEP);
					udp_client.Close();
					return packet;
				}
				catch
				{
					continue;
				}
			}
		}

		private async void recieve_file(string file_name)
		{
			this.Invoke((MethodInvoker)delegate
			{
				lb_log.Items.Add(file_name + " started receiving...");
			});

			Thread.Sleep(1); // Sinkronizacija ????

			UdpClient udp_client = new UdpClient(9000);
			IPEndPoint remoteEP = new IPEndPoint(IPAddress.Any, 9000);
			FileStream fs = new FileStream(Path.Combine(file_directory, file_name.TrimEnd('\0')), FileMode.Create, FileAccess.Write);

			int recieved_packets = 0;

			Dictionary<int, byte[]> packets = new Dictionary<int, byte[]>();
			List<int> not_recieved = new List<int>();

			NetworkStream stream = client.GetStream();
			byte[] start = Encoding.ASCII.GetBytes("START");
			stream.Write(start, 0, start.Length);

			byte[] buffer = new byte[4];
			stream.Read(buffer, 0, buffer.Length);
			
			int max_sequence = BitConverter.ToInt32(buffer, 0);

			udp_client.Client.ReceiveTimeout = 100;

			int sequence = 0;
			while (recieved_packets <= max_sequence)
			{
				try
				{
					byte[] packet = udp_client.Receive(ref remoteEP);
					sequence = BitConverter.ToInt32(packet, 0);
					int dataSize = packet.Length - 4;
					byte[] data = new byte[dataSize];
					Buffer.BlockCopy(packet, 4, data, 0, dataSize);

					if (!packets.ContainsKey(sequence))
					{
						packets.Add(sequence, data);
					}
				} catch (SocketException ex)
				{
				}
				recieved_packets++;
			}

			udp_client.Close();

			for(int i = 0; i <= max_sequence; i++)
			{
                if (!packets.ContainsKey(i))
				{
					packets.Add(i, recieve_again(i, file_name, remoteEP));
                }
            }

			foreach (var packet in packets.OrderBy(x => x.Key))
			{
				fs.Write(packet.Value, 0, packet.Value.Length);
			}

			fs.Close();
		}
		private void lb_files_SelectedIndexChanged(object sender, EventArgs e)
		{

			if (lb_files.SelectedItem == null) return;
			if (lb_files.SelectedItem.ToString().EndsWith("/") || lb_files.SelectedItem.ToString() == "..")
			{
                bt_download.Text = "Open";
            }
            else
			{
                bt_download.Text = "Download";
            }
		}

        private void bt_download_Click(object sender, EventArgs e)
        {
			if(lb_files.SelectedItem == null) return;
			if(file_directory == "")
			{
				this.Invoke((MethodInvoker)delegate
				{
					MessageBox.Show("No directory selected.");
				});
				return;
			}
            NetworkStream stream = client.GetStream();
            string file_name = lb_files.SelectedItem.ToString();
            if (file_name.EndsWith("/") || file_name == "..")
            {
                byte[] buffer = Encoding.ASCII.GetBytes("GETD:" + file_name + ":");
                stream.Write(buffer, 0, buffer.Length);
                this.Invoke((MethodInvoker)delegate
                {
                    lb_files.Items.Clear();
                });
                recieve_file_structure();
            }
            else
            {
                byte[] buffer = Encoding.ASCII.GetBytes("GETF:" + file_name + ":");
                stream.Write(buffer, 0, buffer.Length);
                recieve_file(file_name);
                this.Invoke((MethodInvoker)delegate
                {
                    lb_log.Items.Add($"File {file_name} received successfully.");
                });
            }
        }

        private void bt_changeDir_Click(object sender, EventArgs e)
        {
			fbr.ShowDialog();
			if (fbr.SelectedPath == null)
			{
				this.Invoke((MethodInvoker)delegate
				{
                    MessageBox.Show("No directory selected.");
                });
				return;
			}
			file_directory = fbr.SelectedPath;
			la_path.Text = file_directory;

        }
    }
}

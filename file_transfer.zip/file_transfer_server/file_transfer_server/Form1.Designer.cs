﻿namespace file_transfer_server
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fbd_wd = new System.Windows.Forms.FolderBrowserDialog();
            this.tb_port = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.bt_dir = new System.Windows.Forms.Button();
            this.lb_files = new System.Windows.Forms.ListBox();
            this.la_dir = new System.Windows.Forms.Label();
            this.bt_start = new System.Windows.Forms.Button();
            this.lb_log = new System.Windows.Forms.ListBox();
            this.bt_stop = new System.Windows.Forms.Button();
            this.la_ip = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // fbd_wd
            // 
            this.fbd_wd.SelectedPath = "C:\\file_transfer_server";
            // 
            // tb_port
            // 
            this.tb_port.Location = new System.Drawing.Point(13, 13);
            this.tb_port.Name = "tb_port";
            this.tb_port.Size = new System.Drawing.Size(100, 20);
            this.tb_port.TabIndex = 2;
            this.tb_port.Text = "58";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(119, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Port";
            // 
            // bt_dir
            // 
            this.bt_dir.Location = new System.Drawing.Point(13, 40);
            this.bt_dir.Name = "bt_dir";
            this.bt_dir.Size = new System.Drawing.Size(132, 23);
            this.bt_dir.TabIndex = 4;
            this.bt_dir.Text = "Select working directory";
            this.bt_dir.UseVisualStyleBackColor = true;
            this.bt_dir.Click += new System.EventHandler(this.bt_dir_Click);
            // 
            // lb_files
            // 
            this.lb_files.FormattingEnabled = true;
            this.lb_files.Location = new System.Drawing.Point(195, 16);
            this.lb_files.Name = "lb_files";
            this.lb_files.Size = new System.Drawing.Size(575, 420);
            this.lb_files.TabIndex = 5;
            // 
            // la_dir
            // 
            this.la_dir.AutoSize = true;
            this.la_dir.Location = new System.Drawing.Point(12, 66);
            this.la_dir.Name = "la_dir";
            this.la_dir.Size = new System.Drawing.Size(33, 13);
            this.la_dir.TabIndex = 7;
            this.la_dir.Text = "None";
            // 
            // bt_start
            // 
            this.bt_start.Location = new System.Drawing.Point(13, 139);
            this.bt_start.Name = "bt_start";
            this.bt_start.Size = new System.Drawing.Size(74, 22);
            this.bt_start.TabIndex = 8;
            this.bt_start.Text = "Start Server";
            this.bt_start.UseVisualStyleBackColor = true;
            this.bt_start.Click += new System.EventHandler(this.bt_start_Click);
            // 
            // lb_log
            // 
            this.lb_log.FormattingEnabled = true;
            this.lb_log.HorizontalScrollbar = true;
            this.lb_log.Location = new System.Drawing.Point(15, 172);
            this.lb_log.Name = "lb_log";
            this.lb_log.Size = new System.Drawing.Size(150, 264);
            this.lb_log.TabIndex = 9;
            // 
            // bt_stop
            // 
            this.bt_stop.Enabled = false;
            this.bt_stop.Location = new System.Drawing.Point(93, 139);
            this.bt_stop.Name = "bt_stop";
            this.bt_stop.Size = new System.Drawing.Size(72, 22);
            this.bt_stop.TabIndex = 10;
            this.bt_stop.Text = "Stop Server";
            this.bt_stop.UseVisualStyleBackColor = true;
            this.bt_stop.Click += new System.EventHandler(this.bt_stop_Click);
            // 
            // la_ip
            // 
            this.la_ip.AutoSize = true;
            this.la_ip.Location = new System.Drawing.Point(12, 99);
            this.la_ip.Name = "la_ip";
            this.la_ip.Size = new System.Drawing.Size(20, 13);
            this.la_ip.TabIndex = 11;
            this.la_ip.Text = "IP:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.la_ip);
            this.Controls.Add(this.bt_stop);
            this.Controls.Add(this.lb_log);
            this.Controls.Add(this.bt_start);
            this.Controls.Add(this.la_dir);
            this.Controls.Add(this.lb_files);
            this.Controls.Add(this.bt_dir);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tb_port);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.FolderBrowserDialog fbd_wd;
        private System.Windows.Forms.TextBox tb_port;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button bt_dir;
        private System.Windows.Forms.ListBox lb_files;
        private System.Windows.Forms.Label la_dir;
        private System.Windows.Forms.Button bt_start;
        private System.Windows.Forms.ListBox lb_log;
        private System.Windows.Forms.Button bt_stop;
        private System.Windows.Forms.Label la_ip;
    }
}


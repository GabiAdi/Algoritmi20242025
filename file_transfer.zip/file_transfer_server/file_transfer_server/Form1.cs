﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using System.Net.NetworkInformation;

namespace file_transfer_server
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		string server_path = "";
		int port = 58;
		TcpListener server;
		List<string> server_files = new List<string>();
		List<TcpClient> tcp_clients = new List<TcpClient>();

		private void bt_dir_Click(object sender, EventArgs e)
		{
			fbd_wd.ShowDialog();
			if (fbd_wd.SelectedPath == "")
			{
				this.Invoke((MethodInvoker)delegate
				{
					MessageBox.Show("Please select a directory");
				});
				return;
			}
			server_path = fbd_wd.SelectedPath;
			la_dir.Text = server_path;
		}

		private void bt_start_Click(object sender, EventArgs e)
		{
			if (server_path == "")
			{
				MessageBox.Show("Please select a directory");
				return;
			}

			try
			{
				port = int.Parse(tb_port.Text);
			} catch
			{
				MessageBox.Show("Please enter a valid port number");
				return;
			}

			if (port < 1 || port > 65535)
			{
				MessageBox.Show("Please enter a valid port number");
				return;
			}

			if (lb_log.Items.Count > 0)
			{
				lb_log.Items.Clear();
			}

			if(lb_files.Items.Count > 0)
			{
				lb_files.Items.Clear();
			}

			if(server != null)
			{
				server.Stop();
				server = null;
			}

			IPAddress local_ip = get_local_ip();
			lb_log.Items.Add("Starting server on port " + port + " and IP " + local_ip + " using directory " + server_path);
			la_ip.Text = "IP: " + local_ip.ToString() + ":" + port;

			bt_dir.Enabled = false;
			bt_start.Enabled = false;
			bt_stop.Enabled = true;
			tb_port.Enabled = false;

			server = new TcpListener(local_ip, port);
			server.Start();
			lb_log.Items.Add("Server started");

			foreach(var item in Directory.EnumerateFileSystemEntries(server_path))
			{
				string name = Path.GetFileName(item);
				if (Directory.Exists(item))
				{
					lb_files.Items.Add(name + "/");
					server_files.Add(name + "/");
				}
				else
				{
					lb_files.Items.Add(name);
					server_files.Add(name);
				}
			}

			Task server_task = new Task(accept_tcp);
			server_task.Start();
		}

		private void accept_tcp()
		{
			while(true)
			{
				if(server == null)
				{
					break;
				}

				TcpClient client = server.AcceptTcpClient();
				tcp_clients.Add(client);
				send_file_structure(client, server_path);
				Task client_task = new Task(() => await_client(client));
				client_task.Start();
				this.Invoke((MethodInvoker)delegate
				{
					lb_log.Items.Add("Client connected from " + ((IPEndPoint)client.Client.RemoteEndPoint).Address.ToString() + ":" + ((IPEndPoint)client.Client.RemoteEndPoint).Port.ToString());
				});
			}
		}

		private async void await_client(TcpClient client)
		{
			NetworkStream network_stream = client.GetStream();
			byte[] buffer = new byte[1024];
			int bytes_read = 0;
			string path = server_path;

			while (true)
			{
				if (server == null)
				{
					break;
				}

				if (client == null)
				{
					break;
				}
				try
				{
					bytes_read = network_stream.Read(buffer, 0, buffer.Length);
				} catch
				{
					client.Close();
					this.Invoke((MethodInvoker)delegate
					{
						lb_log.Items.Add("Client disconnected");
					});
					tcp_clients.Remove(client);
					break;
				}

				if (bytes_read != 0)
				{
					string message = Encoding.ASCII.GetString(buffer, 0, bytes_read);

					if(message == "ACK" || message == "START")
					{
						continue;
					}
					string command = message.Split(':')[0];
					string file_name = message.Split(':')[1].TrimEnd('\0', '/');

					this.Invoke((MethodInvoker)delegate
					{
						lb_log.Items.Add("Received: " + Encoding.ASCII.GetString(buffer, 0, bytes_read));
					});

					if (command == "GETF")
					{
						this.Invoke((MethodInvoker)delegate
						{
							lb_log.Items.Add("Sending file " + Path.Combine(path, file_name) + " to client");
						});
						await send_file(Path.Combine(path, file_name), client);
						this.Invoke((MethodInvoker)delegate
						{
							lb_log.Items.Add("Sent file " + file_name + " to client");
						});
					}
					if (command == "GETD")
					{
						if (file_name == "..")
						{
							path = Path.GetDirectoryName(path);
						}
						else
						{
							path = Path.Combine(path, file_name);
						}

						await send_file_structure(client, path);
						this.Invoke((MethodInvoker)delegate
						{
							lb_log.Items.Add("Sent directory " + path + " to client");
						});
					}
					if (command == "GETP")
					{
						int sequence = int.Parse(message.Split(':')[2]);
						await send_packet(sequence, Path.Combine(path, file_name), client);
						this.Invoke((MethodInvoker)delegate
						{
							lb_log.Items.Add("Sent packet " + sequence + " of file " + file_name + " to client");
						});
					}
				}
			}
		}

		private Task send_file_structure(TcpClient client, string path)
		{
			List<string> files = new List<string>();
			if(path != server_path)
			{
				files.Add("..");
			}
			foreach (var item in Directory.EnumerateFileSystemEntries(path))
			{
				string name = Path.GetFileName(item);
				if (Directory.Exists(item))
				{
					files.Add(name + "/");
				}
				else
				{
					files.Add(name);
				}
			}
			byte[] buffer = Encoding.ASCII.GetBytes(string.Join(":", files));
			try
			{
				NetworkStream networkStream = client.GetStream();
				networkStream.Write(buffer, 0, buffer.Length);
			} catch
			{
				client.Close();
				this.Invoke((MethodInvoker)delegate
				{
					lb_log.Items.Add("Client disconnected");
				});
				tcp_clients.Remove(client);
			}

			return Task.CompletedTask;
		}

		private IPAddress get_local_ip()
		{
			foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
			{
                if (ni.OperationalStatus == OperationalStatus.Up && ni.NetworkInterfaceType != NetworkInterfaceType.Loopback && !ni.Description.ToLower().Contains("virtual") && !ni.Description.ToLower().Contains("vmware") && !ni.Description.ToLower().Contains("hyper-v") && !ni.Description.ToLower().Contains("virtualbox") && !ni.Name.ToLower().Contains("loopback"))
				{
                    foreach (UnicastIPAddressInformation ip in ni.GetIPProperties().UnicastAddresses)
					{
                        if (ip.Address.AddressFamily == AddressFamily.InterNetwork)
						{
                            return ip.Address;
                        }
                    }
                }
            }
			return null;
		}

		private void bt_stop_Click(object sender, EventArgs e)
		{
			if(server != null)
			{
				server.Stop();
				server = null;
				lb_log.Items.Add("Server stopped");

				bt_dir.Enabled = true;
				bt_start.Enabled = true;
				bt_stop.Enabled = false;
				tb_port.Enabled = true;
			}
			foreach (var client in tcp_clients)
			{
                client.Close();
            }
		}

		private void Form1_Closing(object sender, FormClosingEventArgs e)
		{
			if (server != null)
			{
				server.Stop();
				server = null;
			}
		}

		private Task send_packet(int sequence, string file_path, TcpClient client)
		{
			byte[] file_data = File.ReadAllBytes(file_path);

			int packet_size = 1024;

			UdpClient udp_client = new UdpClient();
			IPEndPoint endpont = new IPEndPoint(IPAddress.Any, 9000);

			try
			{
				NetworkStream stream = client.GetStream();

				int size = Math.Min(packet_size, file_data.Length);
				byte[] data = new byte[size];
				Array.Copy(file_data, sequence * packet_size, data, 0, size);

				udp_client.Send(data, data.Length, endpont);
			} catch
			{
				client.Close();
				this.Invoke((MethodInvoker)delegate
				{
					lb_log.Items.Add("Client disconnected");
				});
				tcp_clients.Remove(client);
			} finally
			{
				udp_client.Close();
			}

			return Task.CompletedTask;
		}

		private Task send_file(string file_path, TcpClient client)
		{
			byte[] file_data = File.ReadAllBytes(file_path);

			int sequence = 0;
			int packet_size = 1024;
			int total_packets = (int)Math.Ceiling((double)file_data.Length / packet_size);
			int max_sequence = total_packets - 1;

			UdpClient udp_client = new UdpClient();
			IPEndPoint endpont = new IPEndPoint(((IPEndPoint)client.Client.RemoteEndPoint).Address, 9000); // Promeniti

			try
			{ 
				NetworkStream stream = client.GetStream();

				byte[] start_byte = new byte[5];
				int bytesRead = 0;

				while (Encoding.ASCII.GetString(start_byte, 0, Math.Min(bytesRead, start_byte.Length)) != "START")
				{
					bytesRead = stream.Read(start_byte, 0, start_byte.Length);
				}

				this.Invoke((MethodInvoker)delegate
				{
					lb_log.Items.Add("START received");
				});

				stream.Write(BitConverter.GetBytes(max_sequence), 0, sizeof(int));

				for (int i = 0; i < file_data.Length; i += packet_size)
				{
					//if (sequence > 7 && sequence < 27) // Jako vazno, posle testiranja promeniti!!!
					//{
					//	sequence++;
					//	continue;
					//}
					int size = Math.Min(packet_size, file_data.Length - i);
					byte[] data = new byte[size];
					Array.Copy(file_data, i, data, 0, size);

					byte[] header = BitConverter.GetBytes(sequence);
					
					byte[] packet = new byte[header.Length + data.Length];
					Buffer.BlockCopy(header, 0, packet, 0, header.Length);
					Buffer.BlockCopy(data, 0, packet, header.Length, data.Length);

					udp_client.Send(packet, packet.Length, endpont);
					sequence++;
				}
			} catch
			{
				client.Close();
				this.Invoke((MethodInvoker)delegate
				{
					lb_log.Items.Add("Client disconnected");
				});
				tcp_clients.Remove(client);
			}
			finally
			{
				udp_client.Close();
			}

			return Task.CompletedTask;
		}
	}
}

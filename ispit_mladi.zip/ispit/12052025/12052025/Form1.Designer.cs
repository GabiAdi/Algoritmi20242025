﻿namespace _12052025 {
    partial class Form1 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.bt_startTcp = new System.Windows.Forms.Button();
            this.bt_startUdp = new System.Windows.Forms.Button();
            this.tb_TCPPort = new System.Windows.Forms.TextBox();
            this.tb_UDPPort = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bt_startTcp
            // 
            this.bt_startTcp.Location = new System.Drawing.Point(47, 68);
            this.bt_startTcp.Name = "bt_startTcp";
            this.bt_startTcp.Size = new System.Drawing.Size(84, 23);
            this.bt_startTcp.TabIndex = 0;
            this.bt_startTcp.Text = "Pokreni TCP";
            this.bt_startTcp.UseVisualStyleBackColor = true;
            this.bt_startTcp.Click += new System.EventHandler(this.bt_startTcp_Click);
            // 
            // bt_startUdp
            // 
            this.bt_startUdp.Location = new System.Drawing.Point(154, 68);
            this.bt_startUdp.Name = "bt_startUdp";
            this.bt_startUdp.Size = new System.Drawing.Size(93, 23);
            this.bt_startUdp.TabIndex = 1;
            this.bt_startUdp.Text = "Pokreni UDP";
            this.bt_startUdp.UseVisualStyleBackColor = true;
            this.bt_startUdp.Click += new System.EventHandler(this.bt_startUdp_Click);
            // 
            // tb_TCPPort
            // 
            this.tb_TCPPort.Location = new System.Drawing.Point(47, 42);
            this.tb_TCPPort.Name = "tb_TCPPort";
            this.tb_TCPPort.Size = new System.Drawing.Size(84, 20);
            this.tb_TCPPort.TabIndex = 2;
            this.tb_TCPPort.Text = "83";
            // 
            // tb_UDPPort
            // 
            this.tb_UDPPort.Location = new System.Drawing.Point(154, 42);
            this.tb_UDPPort.Name = "tb_UDPPort";
            this.tb_UDPPort.Size = new System.Drawing.Size(93, 20);
            this.tb_UDPPort.TabIndex = 3;
            this.tb_UDPPort.Text = "62";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(47, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "TCP Port";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(151, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "UDP Port";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_UDPPort);
            this.Controls.Add(this.tb_TCPPort);
            this.Controls.Add(this.bt_startUdp);
            this.Controls.Add(this.bt_startTcp);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_startTcp;
        private System.Windows.Forms.Button bt_startUdp;
        private System.Windows.Forms.TextBox tb_TCPPort;
        private System.Windows.Forms.TextBox tb_UDPPort;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}


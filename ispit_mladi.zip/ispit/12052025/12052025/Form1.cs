﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;
using System.Linq.Expressions;

namespace _12052025 {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();

            ip = "127.0.0.1";
            tcp_port = 83;
            udp_port = 62;

            tcp_server = new TcpListener(IPAddress.Parse(ip), tcp_port);

            tcp_spojen = false;
            udp_spojen = false;
        }

        string ip;
        TcpListener tcp_server;
        UdpClient udp_server;
        int tcp_port;
        int udp_port;
        bool tcp_spojen;
        bool udp_spojen;

        private void bt_startTcp_Click(object sender, EventArgs e) {
            if (tcp_spojen) return;
            try
            {
                tcp_port = int.Parse(tb_TCPPort.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            tcp_spojen = true;
            tcp_server.Start();
            Task tcp_task = new Task(accept_tcp);
            tcp_task.Start();
            MessageBox.Show("Pokrenut TCP server na portu " + tcp_port);
        }

        private void bt_startUdp_Click(object sender, EventArgs e) {
            if (udp_spojen) return;
            try
            {
                udp_port = int.Parse(tb_UDPPort.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            udp_spojen = true;
            Task udp_task = new Task(accept_udp);
            udp_task.Start();
            MessageBox.Show("Pokrenut UDP server na portu " + udp_port);
        }

        private void accept_udp() {
            udp_server = new UdpClient(udp_port);
            udp_server.BeginReceive(udp_callback, null);
        }

        private void udp_callback(IAsyncResult ar) {
            try
            {
                IPEndPoint end_point = new IPEndPoint(IPAddress.Any, udp_port);
                byte[] recieved_data = udp_server.EndReceive(ar, ref end_point);

                string message = Encoding.ASCII.GetString(recieved_data);

                if(message == "y") {
                    //MessageBox.Show("Uspjeh");
                    using (UdpClient udp_client = new UdpClient())
                    {
                        udp_client.Connect(end_point.Address, udp_port + 1);
                        byte[] data = Encoding.ASCII.GetBytes("x");
                        udp_client.Send(data, data.Length);
                    }
                } else {
                    this.Invoke((MethodInvoker)delegate
                    {
                        MessageBox.Show("Neuspjeh");
                    });
                }
            } catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            udp_server.BeginReceive(udp_callback, null);
        }

        private void accept_tcp() {
            tcp_server.Start();
            while (true) {
                TcpClient client = tcp_server.AcceptTcpClient();
                Task task = new Task(() => accept_tcp_client(client));
                task.Start();
            } 
        }

        private void accept_tcp_client(TcpClient client) { 
            NetworkStream stream = client.GetStream();
            byte[] buffer = new byte[4096];
            int bytesRead;
            try {
                while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) != 0) {
                    string recievedData = Encoding.ASCII.GetString(buffer, 0, bytesRead);

                    if (recievedData == "y") {
                        byte[] data = Encoding.ASCII.GetBytes("x");
                        stream.Write(data, 0, data.Length);
                    }
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
            finally { 
                client.Close();
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e) {
            try { 
                udp_server.Close();
                tcp_server.Stop();
            } catch {

            }
        }
    }
}

﻿namespace _12052025 {
    partial class Form1 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.bt_startTcp = new System.Windows.Forms.Button();
            this.bt_startUdp = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bt_startTcp
            // 
            this.bt_startTcp.Location = new System.Drawing.Point(47, 68);
            this.bt_startTcp.Name = "bt_startTcp";
            this.bt_startTcp.Size = new System.Drawing.Size(84, 23);
            this.bt_startTcp.TabIndex = 0;
            this.bt_startTcp.Text = "Pokreni TCP";
            this.bt_startTcp.UseVisualStyleBackColor = true;
            this.bt_startTcp.Click += new System.EventHandler(this.bt_startTcp_Click);
            // 
            // bt_startUdp
            // 
            this.bt_startUdp.Location = new System.Drawing.Point(154, 68);
            this.bt_startUdp.Name = "bt_startUdp";
            this.bt_startUdp.Size = new System.Drawing.Size(93, 23);
            this.bt_startUdp.TabIndex = 1;
            this.bt_startUdp.Text = "Pokreni UDP";
            this.bt_startUdp.UseVisualStyleBackColor = true;
            this.bt_startUdp.Click += new System.EventHandler(this.bt_startUdp_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bt_startUdp);
            this.Controls.Add(this.bt_startTcp);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bt_startTcp;
        private System.Windows.Forms.Button bt_startUdp;
    }
}


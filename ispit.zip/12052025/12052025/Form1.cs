﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;
using System.Linq.Expressions;

namespace _12052025 {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();

            ip = "127.0.0.1";
            tcp_port = 83;
            udp_port = 62;

            tcp_server = new TcpListener(IPAddress.Parse(ip), tcp_port);
        }

        string ip;
        TcpListener tcp_server;
        UdpClient udp_server;
        int tcp_port;
        int udp_port;

        private void bt_startTcp_Click(object sender, EventArgs e) {
            tcp_server.Start();
            Task tcp_task = new Task(accept_tcp);
            tcp_task.Start();
            MessageBox.Show("Pokrenut TCP server");
        }

        private void bt_startUdp_Click(object sender, EventArgs e) {
            Task udp_task = new Task(accept_udp);
            udp_task.Start();
            MessageBox.Show("Pokrenut UDP server");
        }

        private void accept_udp() {
            udp_server = new UdpClient(udp_port);
            while (true) {
                udp_server.BeginReceive(udp_callback, null);
            }
        }

        private void udp_callback(IAsyncResult ar) {
            IPEndPoint end_point = new IPEndPoint(IPAddress.Any, udp_port);
            byte[] recieved_data = udp_server.EndReceive(ar, ref end_point);

            string message = Encoding.UTF8.GetString(recieved_data);

            if(message == "y") {
                MessageBox.Show("Uspjeh");
                UdpClient udp_client = new UdpClient();
                udp_client.Connect("127.0.0.1", udp_port + 1);
                byte[] data = Encoding.UTF8.GetBytes("x");
                udp_client.Send(data, data.Length);
            } else {
                MessageBox.Show("Neuspjeh");
            }
        }

        private void accept_tcp() {
            tcp_server.Start();
            while (true) {
                TcpClient client = tcp_server.AcceptTcpClient();
                Task task = new Task(() => accept_tcp_client(client));
                task.Start();
            } 
        }

        private void accept_tcp_client(TcpClient client) { 
            NetworkStream stream = client.GetStream();
            byte[] buffer = new byte[4096];
            int bytesRead;
            try {
                while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) != 0) {
                    string recievedData = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                    if (recievedData == "y") {
                        byte[] data = Encoding.UTF8.GetBytes("x");
                        stream.Write(data, 0, data.Length);
                    }
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
            finally { 
                client.Close();
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e) {
            try { 
                udp_server.Close();
                tcp_server.Stop();
            } catch {

            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1 {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
            ipAddress = "127.0.0.1";
            port = 8889;
            spojen = false;

            server = new TcpListener(IPAddress.Parse(ipAddress), port);
            clients = new List<TcpClient>();
        }

        string ipAddress;
        int port;
        bool spojen;
        TcpListener server;
        List<TcpClient> clients;
        Thread clientThread;


        private void button1_Click(object sender, EventArgs e) {
            server.Start();
            //client = server.AcceptTcpClient();
            while (true) { 
                TcpClient client = server.AcceptTcpClient();
                clients.Add(client);
                MessageBox.Show("Connected: " + clients.Count);
                clientThread = new Thread(() => HandleClient(client));
                clientThread.Start();
            }
        }

        private void HandleClient(TcpClient client) {
            NetworkStream stream = client.GetStream();
            byte[] buffer = new byte[1024];
            int bytesRead;
            spojen = true;
            try {
                while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) != 0) {
                    string receivedData = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                    lb_poruke.Items.Add(receivedData);
                    Broadcast(receivedData, client);
                }
            }
            catch (Exception ex) {
                MessageBox.Show("Error handling client: " + ex.Message);
            }
            finally {
                client.Close();
            }
        }

        private void Broadcast(string receivedData, TcpClient client) {
            byte[] buffer = Encoding.UTF8.GetBytes(receivedData);
            foreach (TcpClient cl in clients) {
                if(cl != client) {
                    try {
                        NetworkStream stream = cl.GetStream();
                        stream.Write(buffer, 0, buffer.Length);
                        stream.Flush();
                    }
                    catch (Exception ex) {
                        MessageBox.Show($"{ex.Message}");
                    }
                }
            }
        }

        private void bt_posalji_Click(object sender, EventArgs e) {
            //string message = tb_poruka.Text;
            //byte[] data = Encoding.UTF8.GetBytes(message);

            //stream.Write(data, 0, data.Length);
            //stream.Flush();
            //lb_poruke.Items.Add(message);
        }

        private void bt_zaustavi_Click(object sender, EventArgs e) {
            server.Stop();
        }
    }
}

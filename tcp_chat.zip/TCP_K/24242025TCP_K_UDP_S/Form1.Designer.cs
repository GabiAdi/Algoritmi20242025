﻿namespace _24242025TCP_K_UDP_S {
    partial class Form1 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.bt_spoji = new System.Windows.Forms.Button();
            this.bt_posalji = new System.Windows.Forms.Button();
            this.lb_poruke = new System.Windows.Forms.ListBox();
            this.tb_poruka = new System.Windows.Forms.TextBox();
            this.tb_username = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // bt_spoji
            // 
            this.bt_spoji.Location = new System.Drawing.Point(12, 415);
            this.bt_spoji.Name = "bt_spoji";
            this.bt_spoji.Size = new System.Drawing.Size(75, 23);
            this.bt_spoji.TabIndex = 0;
            this.bt_spoji.Text = "Spoji se";
            this.bt_spoji.UseVisualStyleBackColor = true;
            this.bt_spoji.Click += new System.EventHandler(this.button1_Click);
            // 
            // bt_posalji
            // 
            this.bt_posalji.Location = new System.Drawing.Point(531, 344);
            this.bt_posalji.Name = "bt_posalji";
            this.bt_posalji.Size = new System.Drawing.Size(75, 23);
            this.bt_posalji.TabIndex = 2;
            this.bt_posalji.Text = "Pokreni server";
            this.bt_posalji.UseVisualStyleBackColor = true;
            this.bt_posalji.Click += new System.EventHandler(this.button3_Click);
            // 
            // lb_poruke
            // 
            this.lb_poruke.FormattingEnabled = true;
            this.lb_poruke.Location = new System.Drawing.Point(208, 47);
            this.lb_poruke.Name = "lb_poruke";
            this.lb_poruke.Size = new System.Drawing.Size(398, 290);
            this.lb_poruke.TabIndex = 3;
            // 
            // tb_poruka
            // 
            this.tb_poruka.Location = new System.Drawing.Point(208, 344);
            this.tb_poruka.Name = "tb_poruka";
            this.tb_poruka.Size = new System.Drawing.Size(317, 20);
            this.tb_poruka.TabIndex = 4;
            // 
            // tb_username
            // 
            this.tb_username.Location = new System.Drawing.Point(94, 417);
            this.tb_username.Name = "tb_username";
            this.tb_username.Size = new System.Drawing.Size(100, 20);
            this.tb_username.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tb_username);
            this.Controls.Add(this.tb_poruka);
            this.Controls.Add(this.lb_poruke);
            this.Controls.Add(this.bt_posalji);
            this.Controls.Add(this.bt_spoji);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_spoji;
        private System.Windows.Forms.Button bt_posalji;
        private System.Windows.Forms.ListBox lb_poruke;
        private System.Windows.Forms.TextBox tb_poruka;
        private System.Windows.Forms.TextBox tb_username;
    }
}


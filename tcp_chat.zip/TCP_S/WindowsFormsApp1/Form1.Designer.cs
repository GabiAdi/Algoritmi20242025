﻿namespace WindowsFormsApp1 {
    partial class Form1 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.bt_pokreni = new System.Windows.Forms.Button();
            this.lb_porukeServer = new System.Windows.Forms.ListBox();
            this.tb_poruka = new System.Windows.Forms.TextBox();
            this.bt_posalji = new System.Windows.Forms.Button();
            this.bt_zaustavi = new System.Windows.Forms.Button();
            this.lb_users = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // bt_pokreni
            // 
            this.bt_pokreni.Location = new System.Drawing.Point(12, 415);
            this.bt_pokreni.Name = "bt_pokreni";
            this.bt_pokreni.Size = new System.Drawing.Size(75, 23);
            this.bt_pokreni.TabIndex = 0;
            this.bt_pokreni.Text = "Pokreni TCP server";
            this.bt_pokreni.UseVisualStyleBackColor = true;
            this.bt_pokreni.Click += new System.EventHandler(this.button1_Click);
            // 
            // lb_porukeServer
            // 
            this.lb_porukeServer.FormattingEnabled = true;
            this.lb_porukeServer.Location = new System.Drawing.Point(193, 60);
            this.lb_porukeServer.Name = "lb_porukeServer";
            this.lb_porukeServer.Size = new System.Drawing.Size(371, 225);
            this.lb_porukeServer.TabIndex = 1;
            // 
            // tb_poruka
            // 
            this.tb_poruka.Location = new System.Drawing.Point(193, 292);
            this.tb_poruka.Name = "tb_poruka";
            this.tb_poruka.Size = new System.Drawing.Size(318, 20);
            this.tb_poruka.TabIndex = 2;
            // 
            // bt_posalji
            // 
            this.bt_posalji.Location = new System.Drawing.Point(518, 292);
            this.bt_posalji.Name = "bt_posalji";
            this.bt_posalji.Size = new System.Drawing.Size(46, 23);
            this.bt_posalji.TabIndex = 3;
            this.bt_posalji.Text = "button1";
            this.bt_posalji.UseVisualStyleBackColor = true;
            this.bt_posalji.Click += new System.EventHandler(this.bt_posalji_Click);
            // 
            // bt_zaustavi
            // 
            this.bt_zaustavi.Location = new System.Drawing.Point(93, 415);
            this.bt_zaustavi.Name = "bt_zaustavi";
            this.bt_zaustavi.Size = new System.Drawing.Size(75, 23);
            this.bt_zaustavi.TabIndex = 5;
            this.bt_zaustavi.Text = "Zaustavi TCP";
            this.bt_zaustavi.UseVisualStyleBackColor = true;
            this.bt_zaustavi.Click += new System.EventHandler(this.bt_zaustavi_Click);
            // 
            // lb_users
            // 
            this.lb_users.FormattingEnabled = true;
            this.lb_users.Location = new System.Drawing.Point(13, 60);
            this.lb_users.Name = "lb_users";
            this.lb_users.Size = new System.Drawing.Size(155, 225);
            this.lb_users.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lb_users);
            this.Controls.Add(this.bt_zaustavi);
            this.Controls.Add(this.bt_posalji);
            this.Controls.Add(this.tb_poruka);
            this.Controls.Add(this.lb_porukeServer);
            this.Controls.Add(this.bt_pokreni);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_pokreni;
        private System.Windows.Forms.ListBox lb_porukeServer;
        private System.Windows.Forms.TextBox tb_poruka;
        private System.Windows.Forms.Button bt_posalji;
        private System.Windows.Forms.Button bt_zaustavi;
        private System.Windows.Forms.ListBox lb_users;
    }
}

